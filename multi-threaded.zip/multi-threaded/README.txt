This README explains the steps required to run the Assignment 1 files

Contents: 

1. Servers.java
2. Intermediate.java
3. Client.java
4. README.txt

Steps:
1. Open 3 Terminals in the Directory where you extracted the .zip file
2. compile files
3. type the following command: "java Servers" in the first terminal
4. type the following command: "java Intermediate" in the second terminal
6. type the following command: "java Client" in the terminals


